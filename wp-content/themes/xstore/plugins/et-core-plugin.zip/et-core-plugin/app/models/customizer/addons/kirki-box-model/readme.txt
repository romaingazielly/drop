=== Kirki Accessible-Text Colorpicker ===
Contributors: aristath, wplemon
Tags: customizer, kirki
Requires at least: 4.9
Tested up to: 5.0
Stable tag: 1.0


== Description ==

description for this product can be found on https://wplemon.com/downloads/kirki-accessible-text-colorpicker/

== Changelog ==

= 1.0 =

* Initial release
