<?php
/**
 * The look shortcode.
 *
 * @since      1.4.4
 * @package    ETC
 * @subpackage ETC/Controllers/vc/class
 */
if ( class_exists( 'WPBakeryShortCode' ) ) {
	class WPBakeryShortCode_ET_The_Look extends \WPBakeryShortCode {
	}
}
